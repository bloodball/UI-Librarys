# Nexus-Button
Nexus Button is a custom button implementation on Roblox
to provide a unique look. Additional functionality is included,
like the ability to make inputs to mouse events and display
a controller icon when a controller is plugged in.