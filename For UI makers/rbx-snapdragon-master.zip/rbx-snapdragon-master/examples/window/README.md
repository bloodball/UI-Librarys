# Window
This example produces two "Window" GUIs, one of which is entirely draggable, the other which is only draggable via a "titlebar"