# Slider
Creates two sliders, both only allowing dragging on the X axis.

The first slider, will allow you to freely drag the GUI within the parent frame's boundaries.

The second slider, will allow you to drag the GUI within the parent frame's boundaries every 20 pixels.